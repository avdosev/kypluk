#ifndef _kyplukTypedef_H_
#define _kyplukTypedef_H_
	
	typedef unsigned int Size_t;
	
#endif

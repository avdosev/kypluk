#ifndef _kypluk_style_syntactic_
#ifdef USING_KYPLUK_STYLE

	#define IF(puk) if(puk) {
	#define ELSE } else {
	#define ELIF(puk) } else { if(puk) {
	#define END }

#endif
#endif

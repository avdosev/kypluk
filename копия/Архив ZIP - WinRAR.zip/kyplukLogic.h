#ifndef _kyplukLogic_H_
#define _kypluklogic_H_

#define NOT(puk) (!(puk))
#define NOR(puk, kup) NOT((puk) || (kup))
#define NAND(puk, kup) NOT((puk) && (kup))
#define XOR(puk, kup) ((puk) != (kup))
#define EQV(puk, kup) ((puk) == (kup))

#endif

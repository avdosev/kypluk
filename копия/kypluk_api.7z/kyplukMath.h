#ifndef _kyplukmath_h_
#define _kyplukmath_h_

const double pi = 3.141592653589;
const double e  = 2.718281828459;

unsigned long long int factorial (unsigned short int x) {
	return x==0 ? 1 : x * factorial (x - 1);
}

template <class f>
short int sign(f chislo) {
	if (chislo>0)
		return 1;
	else if (chislo<0)
		return -1;
	return 0;
}

template <class f>
f abs (f chislo) {
	return chislo < 0 ? -chislo : chislo;
}

template <class f>
f pow (f chislo, unsigned int stepen) {
	return stepen == 0 ? 1 : chislo * pow(chislo, stepen-1);
}

template <class f>
f max (f &raz, f &dva) {
	return raz > dva ? raz : dva;
}

template <class f>
f min (f raz, f dva) {
	return raz < dva ? raz : dva;
}

double sin (double alpha, double tochnost = 0.0001) {
	double betha = (alpha*pi)/180.0;
	double predtoch = betha, result = 0.0;
	for (int i = 1, j = 0; abs(predtoch) > tochnost; i+=2, j++) {
		predtoch = (pow(betha, i)/factorial(i));
		result += ((pow(-1, j)) * predtoch);
	}
	return result;
}

double cos (double alpha, double tochnost = 0.0001) {
	double betha = (alpha*pi)/180.0;
	double predtoch = betha, result = 0.0;
	for (int i = 1, j = 0; abs(predtoch) > tochnost; i+=2, j++) {
		predtoch = (pow(betha, i)/factorial(i));
		result += ((pow(-1, j)) * predtoch);
	}
	return result;
}

#endif
